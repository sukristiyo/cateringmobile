part of '../ui/pages/pages.dart';

class Constanta {
  static String baseApiUrl = "http://10.0.2.2//catering";
}
